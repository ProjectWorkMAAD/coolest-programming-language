from setuptools import setup, find_packages

setup(
    name='twitter_stream',
    version='0.1',
    description='Twitter Stream Listener',
    author='Alex0494',
    packages=find_packages(),
)
